library(tidyverse)
library(data.table)

df3 <- read.csv("exp2_data_3afc_raw.csv", header = TRUE)
df2 <- read.csv("exp2_data_2afc_raw.csv", header = TRUE)
df <- rbind(df3, df2)
df <- filter(df, !is.na(chosenItem) | rt >= 0.25)
df3 <- filter(df, condition < 1)
df2 <- filter(df, condition >= 1)
################################################################################
# Exclusion Criteria 1: accuracy
group_by(df3, subj, condition) %>% 
  summarise(acc = sum(corr) / n()) %>% 
  as.data.frame() %>% 
  mutate(isExclude = ifelse(acc <= 0.55, 1, 0)) %>% 
  subset(isExclude == 1)
## subj07 is dropped out
df3 <- filter(df3, subj != "subj07")
df2 <- filter(df2, subj != "subj07")
df  <- filter(df, subj != "subj07")

#Exclusion Criteria 2: omega estimates
source("rc2.R")
subset(fits, isExclude == 1)
## No one is excluded

# Exclusion Criteria 3: RTs
nTrial_3afc <- 1728
nTrial_2afc <- 576
group_by(df, subj) %>% 
  summarise(N = n(), Prop = N / (nTrial_3afc + nTrial_2afc)) %>% 
  mutate(isExclude = if_else(Prop < 0.9, 1, 0)) %>% 
  subset(isExclude == 1)
## No one is excluded

#Exclusion Criteria 4: confidence level
group_by(df, subj, conf) %>%
  summarise(N = n()) -> conf_level
group_by(df, subj) %>% 
  summarise(N_total = n()) %>%
  slice(rep(1:n(), each = 4)) %>% 
  mutate(conf_level = conf_level$N, Prop = conf_level / N_total, isExclude = if_else(Prop > 0.7, 1, 0)) %>% 
  subset(isExclude == 1)
## No one is excluded

write.csv(df3, "exp2_data_3afc_processed.csv", row.names = F)
write.csv(df2, "exp2_data_2afc_processed.csv", row.names = F)