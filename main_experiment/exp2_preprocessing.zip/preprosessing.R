library(tidyverse)
library(data.table)

files <- list.files(pattern = ".csv", recursive = TRUE)
nTrials <- 72
df <- data.frame()

for (i in 1:length(files)){
  error_detected <- FALSE
  d <- data.frame()
  tryCatch(
    {fread(files[i], header = TRUE) %>% 
        select(participant, Condition, Nalt, Val1, Val2, Val3, UVal, LVal, RVal, 
               ChoiceRT, ChosenITM, CorrectITM, Conf, ConfRT) %>% 
        filter(!is.na(Condition)) %>% 
        as.data.frame() -> d
    }, error = function(e){
      error_detected <- TRUE
    }
  )
  if (error_detected){
    next
  }
  if (nrow(d) < 72){
    next
  }
  if ((nrow(d) / nTrials) %% 1 != 0){
    nComplete <- floor(nrow(d) / nTrials) * nTrials
    d <- d[1:nComplete, ]
  }
  df <- rbind(df, d)
}
colnames(df) <- c("subj", "condition", "nAlt", "val1", "val2", "val3", "upVal", "leftVal", "rightVal", "rt", "chosenPos", "correctPos", "conf", "rt2")
df <- mutate(df, corr = ifelse(chosenPos == correctPos, 1, 0), 
             targetPos = ifelse(upVal == val1, "up", ifelse(leftVal == val1, "left", "right")), 
             distractorPos = ifelse(upVal == val2, "up", ifelse(leftVal == val2, "left", "right")), 
             dudPos = ifelse(upVal == val3, "up", ifelse(leftVal == val3, "left", "right")))
df <- mutate(df, chosenItem = ifelse(chosenPos == targetPos, "target", ifelse(chosenPos == distractorPos, "distractor", ifelse(chosenPos == dudPos, "dud", NA))))
df$rt <- suppressWarnings(as.numeric(df$rt))
df$rt2 <- suppressWarnings(as.numeric(df$rt2))
df$conf <- ifelse(df$conf == 0, NA, df$conf)
df$chosenPos <- ifelse(df$chosenPos == "[]", NA, df$chosenPos)

df$subj <- gsub("_1", "", df$subj)
df$subj <- gsub("sub0", "subj0", df$subj)
df$subj <- gsub("_day3", "", df$subj)
df$subj <- gsub("_day4", "", df$subj)

write.csv(filter(df, condition < 1), "exp2_data_3afc_raw.csv", row.names = F)
write.csv(filter(df, condition >= 1), "exp2_data_2afc_raw.csv", row.names = F)
